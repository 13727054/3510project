import React, { useState } from 'react';
import axios from 'axios';
import '../css/AddBook.css'; // Import CSS file

const AddBook = () => {
    // State for form fields
    const [name, setName] = useState('');
    const [author, setAuthor] = useState('');
    const [content, setContent] = useState('');
    const [message, setMessage] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        
        try {
            // Make a POST request to the /books endpoint
            const response = await axios.post('http://localhost:3001/books', {
                name,
                author,
                content
            });

            // Clear input fields and set success message
            setName('');
            setAuthor('');
            setContent('');
            setMessage(`Book created successfully: ${response.data.name}`);
        } catch (error) {
            setMessage(`Error creating book: ${error.response?.data?.message || error.message}`);
        }
    };

    return (
        <div>
            <h2>Create a New Book</h2>
            {message && <p className="message">{message}</p>}
            <form onSubmit={handleSubmit}>
                <div>
                    <label>
                        Name:
                        <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
                    </label>
                </div>
                <div>
                    <label>
                        Author:
                        <input type="text" value={author} onChange={(e) => setAuthor(e.target.value)} required />
                    </label>
                </div>
                <div>
                    <label>
                        Content:
                        <textarea value={content} onChange={(e) => setContent(e.target.value)} required />
                    </label>
                </div>
                <button type="submit">Create Book</button>
            </form>
        </div>
    );
};

export default AddBook;