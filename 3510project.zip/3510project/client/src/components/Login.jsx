import React, { useState } from 'react';
import '../css/Login.css'; // Ensure path is correct
import axios from 'axios';

const Login = () => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [role, setRole] = useState('admin');

    const handleSubmit = () => {
        axios
            .post('http://localhost:3001/auth/login', { username, password, role })
            .then(res => {
                console.log('Response:', res.data);
                alert('Login successful!'); // You may want to redirect the user or store some token
            })
            .catch(err => {
                if (err.response) {
                    console.error('Error response:', err.response.data);
                    alert(`Error: ${err.response.data.message}`);
                } else if (err.request) {
                    console.error('Error request:', err.request);
                    alert('No response from server. Please try again.');
                } else {
                    console.error('Error message:', err.message);
                }
            });
    };

    return (
        <div className='login-page'>
            <div className="login-container">
                <h2>Login</h2><br />
                <div className="form-group">
                    <label htmlFor="username">Username</label>
                    <input
                        type="text"
                        placeholder='Enter Username'
                        onChange={(e) => setUsername(e.target.value)}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        placeholder='Enter Password'
                        onChange={(e) => setPassword(e.target.value)}
                    />
                </div>
                <div className="form-group">
                    <label htmlFor="role">Role:</label>
                    <select
                        name="role"
                        id="role"
                        onChange={(e) => setRole(e.target.value)}
                    >
                        <option value="admin">Admin</option>
                        <option value="student">Student</option>
                    </select>
                </div>
                <button className='btn-login' onClick={handleSubmit}>Login</button>
            </div>
        </div>
    );
};

export default Login;