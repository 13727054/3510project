import React, { useEffect, useState } from 'react';
import axios from 'axios';
import '../css/Dashboard.css'; // Import the CSS file for styling

const Books = () => {
    const [books, setBooks] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchBooks = async () => {
            try {
                const response = await axios.get('http://localhost:3001/books');
                setBooks(response.data);
            } catch (err) {
                setError(err.message);
            } finally {
                setLoading(false);
            }
        };

        fetchBooks();
    }, []);

    if (loading) {
        return <div className="books-container">Loading...</div>; // Ensure loading is also inside the styled div
    }

    if (error) {
        return <div className="books-container">Error: {error}</div>; // Same here for error
    }

    return (
        <div className="books-container"> {/* Apply the pale blue background */}
            <h1>Books List</h1>
            <ul>
                {books.map(book => (
                    <li key={book._id}>
                        <h3>{book.name}</h3>
                        <p>Author: {book.author}</p>
                        <p>{book.content}</p>
                    </li>
                ))}
            </ul>
        </div>
    );
};

export default Books;