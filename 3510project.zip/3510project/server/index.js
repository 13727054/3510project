const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3001;

const Book = require("./models/book.cjs");
const mongoose = require('mongoose');

// CORS configuration
const corsOptions = {
    origin: 'http://localhost:5173', // Allow requests from this origin
    methods: ['GET', 'POST'], // Specify allowed methods if needed
    credentials: true, // Allow credentials if necessary (e.g., cookies, authorization headers)
};

// Middleware
app.use(cors(corsOptions)); // Enable CORS with the specified options
app.use(bodyParser.json()); // Parse JSON bodies

// Connect to MongoDB
mongoose.connect("mongodb+srv://student:student@cluster0.mrbow.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0", { 
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => {
    console.log("MongoDB connected");
})
.catch((err) => {
    console.error("MongoDB connection error:", err);
});

// Retrieve all books
app.get("/books", async (req, res) => {
    try {
        const books = await Book.find(); // Use Mongoose to retrieve all books
        res.status(200).json(books); // Respond with the list of books
        console.log("Success retrieve books");
    } catch (error) {
        console.error("Error retrieving books:", error);
        res.status(500).json({ message: "Internal server error" });
    }
});

// Dummy user data for authentication (for demo purposes)
const users = [
    { username: 'admin', password: 'admin123', role: 'admin' },
    { username: 'student', password: 'student123', role: 'student' },
];

// Authentication route
app.post('/auth/login', (req, res) => {
    const { username, password, role } = req.body;

    // Find the user
    const user = users.find(user => user.username === username && user.password === password && user.role === role);

    if (user) {
        res.status(200).json({ message: 'Login successful!', user });
    } else {
        res.status(401).json({ message: 'Invalid credentials or role!' });
    }
});

app.post('/books', async (req, res) => {
    const { name, author, content } = req.body;

    // Create a new book instance
    const newBook = new Book({
        name,
        author,
        content
    });

    try {
        // Save the book to the database
        const savedBook = await newBook.save();
        res.status(201).json(savedBook); // Respond with the created book and a 201 status code
    } catch (error) {
        res.status(400).json({ message: error.message }); // Handle error if saving fails
    }
});


// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});